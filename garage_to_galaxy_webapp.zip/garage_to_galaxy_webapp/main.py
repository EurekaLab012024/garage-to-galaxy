
import os
os.system("python3 garage_to_galaxy_launcher.py")
